﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapToTexture : MonoBehaviour {

    int[,] map;
    public GameObject DeadTile;
    public GameObject tileGrass;
    public GameObject tileRock;
    public GameObject tilePath;
    public GameObject tileTree;
    public GameObject tileBlock;
    TileMapperOld mapper = new TileMapperOld();

    //Gets the generated map
    void SetMapNewMap()
    {
        //Copy the generated map
        mapper.GenerateMap(TileMapperOld.eMapStyle.Forest, System.Convert.ToInt32("1111", 2));
        mapper.StoreMap("C:\\Users\\cwlarson\\OneDrive\\Tile Mapper\\Assets\\Scripts\\Test.txt");
        map = mapper.GetMap();
    }


    //TODO:Make this function place the right tiles
    //Instantiates the tile objects
    void TileInstantiater()
    {
        for(int row = 0; row < map.GetLength(0); ++row)
        {
            for(int col = 0; col < (map.Length / map.GetLength(0)); ++col){



                switch (map[row, col])
                {
                    case 0://And DeadTiles
                        {
                            Instantiate(DeadTile.transform.GetChild(0), new Vector2(col, 0 - row), Quaternion.identity);
                            break;
                        }
                    case 1://PATH---------------------------------------------------------------------------------------------------------------------------------------
                        {
                            int counter = 0;
                            for (int i = row - 1; i <= row + 1; ++i)
                            {
                                for (int j = col - 1; j <= col + 1; ++j)
                                {
                                    if (i >= 0 && i < TileMapperOld.height && j >= 0 && j < TileMapperOld.width)
                                    {
                                        if (map[i, j] == 1)
                                        {
                                            counter++;
                                        }
                                    }
                                }
                            }                            
                            if (counter == 9)
                                Instantiate(tilePath.transform.GetChild(0), new Vector2(col, 0 - row), Quaternion.identity);
                            else if (col - 1 >= 0 && col + 1 < TileMapperOld.width && row - 1 >= 0 && row + 1 < TileMapperOld.height)//UpLeft path
                            {
                                if (map[row - 1, col] != 1 && map[row, col - 1] != 1)//UpLeftOuter
                                    Instantiate(tilePath.transform.GetChild(11), new Vector2(col, 0 - row), Quaternion.identity);
                                else if(map[row -1, col - 1] != 1 && map[row, col - 1] == 1 && map[row - 1, col] == 1)//UpLeftInner
                                    Instantiate(tilePath.transform.GetChild(13), new Vector2(col, 0 - row), Quaternion.identity);
                                else if (map[row + 1, col] != 1 && map[row, col - 1] != 1)//DownLeftOuter
                                    Instantiate(tilePath.transform.GetChild(10), new Vector2(col, 0 - row), Quaternion.identity);
                                else if (map[row, col - 1] == 1 && map[row + 1, col - 1] != 1 && map[row + 1, col] == 1)//DownLeftInner
                                    Instantiate(tilePath.transform.GetChild(16), new Vector2(col, 0 - row), Quaternion.identity);
                                else if (map[row - 1, col] != 1 && map[row, col + 1] != 1)//UpRightOuter
                                    Instantiate(tilePath.transform.GetChild(12), new Vector2(col, 0 - row), Quaternion.identity);
                                else if (map[row, col + 1] == 1 && map[row - 1, col + 1] != 1 && map[row - 1, col] == 1)//UpRightInner
                                    Instantiate(tilePath.transform.GetChild(14), new Vector2(col, 0 - row), Quaternion.identity);
                                else if (map[row + 1, col] != 1 && map[row, col + 1] != 1)//DownRightOuter
                                    Instantiate(tilePath.transform.GetChild(9), new Vector2(col, 0 - row), Quaternion.identity);
                                else if (map[row, col + 1] == 1 && map[row + 1, col + 1] != 1 && map[row + 1, col] == 1)//DownRightInner
                                    Instantiate(tilePath.transform.GetChild(15), new Vector2(col, 0 - row), Quaternion.identity);
                                else if (map[row, col - 1] != 1 && map[row, col + 1] == 1 && map[row - 1, col] == 1 && map[row + 1, col] == 1)//Left
                                    Instantiate(tilePath.transform.GetChild(1), new Vector2(col, 0 - row), Quaternion.identity);
                                else if (map[row, col - 1] == 1 && map[row, col + 1] != 1 && map[row - 1, col] == 1 && map[row + 1, col] == 1)//Right
                                    Instantiate(tilePath.transform.GetChild(2), new Vector2(col, 0 - row), Quaternion.identity);
                                else if (map[row - 1, col] == 1 && map[row + 1, col] != 1 && map[row, col + 1] == 1 && map[row, col - 1] == 1)//Down
                                    Instantiate(tilePath.transform.GetChild(3), new Vector2(col, 0 - row), Quaternion.identity);
                                else if (map[row + 1, col] == 1 && map[row - 1, col] != 1 && map[row, col + 1] == 1 && map[row, col - 1] == 1)//UP
                                    Instantiate(tilePath.transform.GetChild(4), new Vector2(col, 0 - row), Quaternion.identity);
                            }
                            else//Handle edge cases
                            {
                                //up
                                if(row == 0)
                                {
                                    if (map[row, col + 1] == 1 && map[row, col - 1] != 1 && map[row + 1, col + 1] == 1 && map[row + 1, col] != 1)//DownLeftOuter
                                        Instantiate(tilePath.transform.GetChild(10), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row, col + 1] == 1 && map[row, col - 1] != 1 && map[row + 1, col + 1] == 1 && map[row + 1, col] == 1)//Left
                                        Instantiate(tilePath.transform.GetChild(1), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row + 1, col - 1] != 1 && map[row, col - 1] == 1 && map[row + 1, col] == 1)//DownLeftInner
                                        Instantiate(tilePath.transform.GetChild(16), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row, col - 1] == 1 && map[row, col + 1] != 1 && map[row + 1, col - 1] == 1 && map[row + 1, col] != 1)//DownRightOuter
                                        Instantiate(tilePath.transform.GetChild(9), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row, col - 1] == 1 && map[row, col + 1] != 1 && map[row + 1, col - 1] == 1 && map[row + 1, col] == 1)//Right
                                        Instantiate(tilePath.transform.GetChild(2), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row + 1, col + 1] != 1 && map[row, col + 1] == 1 && map[row + 1, col] == 1)//DownRightInner
                                        Instantiate(tilePath.transform.GetChild(15), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row + 1, col - 1] == 1 && map[row + 1, col + 1] == 1)//Mid
                                        Instantiate(tilePath.transform.GetChild(0), new Vector2(col, 0 - row), Quaternion.identity);

                                }
                                //left
                                if(col == 0)
                                {
                                    if(map[row - 1, col] != 1 && map[row, col + 1] == 1)//Up
                                        Instantiate(tilePath.transform.GetChild(4), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if(map[row - 1, col] != 1 && map[row - 1, col + 1] != 1 && map[row, col + 1] != 1)//UpRightOuter
                                        Instantiate(tilePath.transform.GetChild(12), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if(map[row - 1, col] == 1 && map[row - 1, col + 1] != 1 && map[row, col + 1] == 1)//UpRightInner
                                        Instantiate(tilePath.transform.GetChild(14), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row + 1, col] != 1 && map[row, col + 1] == 1)//Down
                                        Instantiate(tilePath.transform.GetChild(3), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row + 1, col] != 1 && map[row + 1, col + 1] != 1 && map[row, col + 1] != 1)//DownRightOuter
                                        Instantiate(tilePath.transform.GetChild(9), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row + 1, col] == 1 && map[row + 1, col + 1] != 1 && map[row, col + 1] == 1)//DownRightInner
                                        Instantiate(tilePath.transform.GetChild(15), new Vector2(col, 0 - row), Quaternion.identity);
                                    else//Mid
                                        Instantiate(tilePath.transform.GetChild(0), new Vector2(col, 0 - row), Quaternion.identity);
                                }
                                //right
                                if(col == TileMapperOld.width - 1)
                                {
                                    if (map[row - 1, col] != 1 && map[row, col - 1] == 1)//Up
                                        Instantiate(tilePath.transform.GetChild(4), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row - 1, col] != 1 && map[row - 1, col - 1] != 1 && map[row, col - 1] != 1)//UpLeftOuter
                                        Instantiate(tilePath.transform.GetChild(11), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row - 1, col] == 1 && map[row - 1, col - 1] != 1 && map[row, col - 1] == 1)//UpLeftInner
                                        Instantiate(tilePath.transform.GetChild(13), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row + 1, col] != 1 && map[row, col - 1] == 1)//Down
                                        Instantiate(tilePath.transform.GetChild(3), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row + 1, col] != 1 && map[row + 1, col - 1] != 1 && map[row, col - 1] != 1)//DownLeftOuter
                                        Instantiate(tilePath.transform.GetChild(10), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row + 1, col] == 1 && map[row + 1, col - 1] != 1 && map[row, col - 1] == 1)//DownLeftInner
                                        Instantiate(tilePath.transform.GetChild(16), new Vector2(col, 0 - row), Quaternion.identity);
                                    else//Mid
                                        Instantiate(tilePath.transform.GetChild(0), new Vector2(col, 0 - row), Quaternion.identity);
                                }
                                //down
                                if(row == TileMapperOld.height - 1)
                                {
                                    if (map[row, col + 1] == 1 && map[row, col - 1] != 1 && map[row - 1, col + 1] == 1 && map[row - 1, col] != 1)//UpLeftOuter
                                        Instantiate(tilePath.transform.GetChild(11), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row, col + 1] == 1 && map[row, col - 1] != 1 && map[row - 1, col + 1] == 1 && map[row - 1, col] == 1)//Left
                                        Instantiate(tilePath.transform.GetChild(1), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row - 1, col - 1] != 1 && map[row, col - 1] == 1 && map[row - 1, col] == 1)//UpLeftInner
                                        Instantiate(tilePath.transform.GetChild(13), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row, col - 1] == 1 && map[row, col + 1] != 1 && map[row - 1, col - 1] == 1 && map[row - 1, col] != 1)//UpRightOuter
                                        Instantiate(tilePath.transform.GetChild(12), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row, col - 1] == 1 && map[row, col + 1] != 1 && map[row - 1, col - 1] == 1 && map[row - 1, col] == 1)//Right
                                        Instantiate(tilePath.transform.GetChild(2), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row - 1, col + 1] != 1 && map[row, col + 1] == 1 && map[row - 1, col] == 1)//UpRightInner
                                        Instantiate(tilePath.transform.GetChild(14), new Vector2(col, 0 - row), Quaternion.identity);
                                    else if (map[row - 1, col - 1] == 1 && map[row - 1, col + 1] == 1)//Mid
                                        Instantiate(tilePath.transform.GetChild(0), new Vector2(col, 0 - row), Quaternion.identity);
                                }
                            }                          
                            break;
                        }
                    case 2://GRASS--------------------------------------------------------------------------------------------------------------------------------------
                        {
                            //If near the path, use the default grass
                            int grassBuffer = 0;
                            for (int i = row - grassBuffer; i <= row + grassBuffer; ++i)
                            {
                                for (int j = col - grassBuffer; j <= col + grassBuffer; ++j)
                                {
                                    if (i >= 0 && i < TileMapperOld.height && j >= 0 && j < TileMapperOld.width)
                                    {
                                        if (map[i, j] == 1)
                                        {
                                            SpriteRenderer.Instantiate(tileGrass.transform.GetChild(0), new Vector2(col, 0 - row), Quaternion.identity);
                                        }
                                    }
                                }
                            }
                            //If away from the path use random grass
                            int rand = Random.Range(1, tileGrass.transform.childCount - 2);
                            SpriteRenderer.Instantiate(tileGrass.transform.GetChild(rand), new Vector2(col, 0 - row), Quaternion.identity);
                            break;
                        }
                    case 3://TREE---------------------------------------------------------------------------------------------------------------------------------------
                        {
                            SpriteRenderer.Instantiate(tileGrass.transform.GetChild(0), new Vector2(col, 0 - row), Quaternion.identity);
                            int counter = 0;
                            for (int i = row - 3; i <= row; ++i)
                            {
                                for (int j = col - 1; j <= col + 1; ++j, counter++)
                                {
                                    if (i >= 0 && i < TileMapperOld.height && j >= 0 && j < TileMapperOld.width)
                                    {
                                        SpriteRenderer.Instantiate(tileTree.transform.GetChild(counter), new Vector2(j, 0 - i), Quaternion.identity);
                                    }
                                }
                            }
                            break;
                        }
                    case 4://ROCK---------------------------------------------------------------------------------------------------------------------------------------
                        {

                            //int rand = Random.Range(2, tileGrass.transform.childCount - 3);
                            SpriteRenderer.Instantiate(tileGrass.transform.GetChild(0), new Vector2(col, 0 - row), Quaternion.identity);

                            
                            int rand2 = Random.Range(0, tileRock.transform.childCount);
                            SpriteRenderer.Instantiate(tileRock.transform.GetChild(rand2), new Vector2(col, 0 - row), Quaternion.identity);
                            break;
                        }
                    case 5://Bush---------------------------------------------------------------------------------------------------------------------------------------
                        SpriteRenderer.Instantiate(tileGrass.transform.GetChild(8), new Vector2(col, 0 - row), Quaternion.identity);
                        break;
                    case 6://Log----------------------------------------------------------------------------------------------------------------------------------------
                        SpriteRenderer.Instantiate(tileGrass.transform.GetChild(7), new Vector2(col, 0 - row), Quaternion.identity);
                        break;
                    case 7://Water--------------------------------------------------------------------------------------------------------------------------------------
                        break;
                    case 8://Boarder------------------------------------------------------------------------------------------------------------------------------------
                        {
                            SpriteRenderer.Instantiate(tileBlock.transform.GetChild(0), new Vector2(col, 0 - row), Quaternion.identity);
                            int counter = 0;
                            for (int i = row - 3; i <= row; ++i)
                            {
                                for (int j = col - 1; j <= col + 1; ++j, counter++)
                                {
                                    if (i >= 0 && i < TileMapperOld.height && j >= 0 && j < TileMapperOld.width)
                                    {
                                        if(i > 0 && i < TileMapperOld.height - 1)
                                        {
                                            

                                        }
                                        SpriteRenderer.Instantiate(tileBlock.transform.GetChild(counter), new Vector2(j, 0 - i), Quaternion.identity);
                                    }
                                }
                            }
                            break;
                        }
                    default:
                        Instantiate(tileBlock, new Vector2(col, 0 - row), Quaternion.identity);
                        break;
                }
                
            }
        }
    }

    //Applies the textures to the tiles
    void SetTextures()
    {

    }

	// Use this for initialization
	void Awake () {
        SetMapNewMap();
        TileInstantiater();
	}
}
