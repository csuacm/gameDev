﻿using UnityEngine;

public class StatsUpdateTrigger : MonoBehaviour
{
    /// <summary>
    /// Statistics object that will receive updates from all other Statistics objects in the scene
    /// </summary>
    public Statistics statsToUpdate;

    /// <summary>
    /// Sets default values on attached Statistics object,
    /// then updates that object with all other Statistics objects/scripts that are in the scene
    /// </summary>
    public void UpdateStats()
    {
        statsToUpdate.SetDefaultValues();
        Debug.Log("==>Before: \n" + statsToUpdate.ToString());
        Statistics.UpdateStatsEvent.Invoke(statsToUpdate);
        Debug.Log("==>After: \n" + statsToUpdate.ToString());
    }
}
