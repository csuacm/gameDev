﻿[System.Serializable]
public class CharacterClass
{
    public int BaseHP = 1;
    public int BaseDefense = 1;
    public int BaseMeleeAttack = 1;
    public int BaseRangedAttack = 1;
    public int BaseResourcePool = 0;

    public int BaseStrength = 1;
    public int BaseAgility = 1;
    public int BaseIntelligence = 1;
}
