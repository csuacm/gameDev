﻿using System;
using UnityEngine;
public class Node : IComparable, IEquatable<Node>, IEquatable<Vector2>
{
    public Node ParentNode { get; set; }
    public Vector2 Position { get; set; }

    /// <summary>
    /// Parent's cost from start + movement cost to get from parent to this node + estimated distance to end
    /// </summary>
    public float FScore { get; set; }
    /// <summary>
    /// Total movement cost from start node
    /// </summary>
    public float CostFromStart { get; set; }

    private float x;
    private float y;
    public Node(Vector2 vect, float fScore = 1.0f)
    {
        Position = vect;
        FScore = fScore;
        ParentNode = this;
    }

    public Node(int x, int y, float fScore = 1.0f)
    {
        Position = new Vector2(x, y);
        FScore = fScore;
        ParentNode = this;
    }

    public Node(Vector2 vect, float fScore, Node parent)
    {
        Position = vect;
        FScore = fScore;
        ParentNode = parent;
    }

    public Vector2 GetWorldVector()
    {
        return new Vector2(Position.x,-Position.y);
    }

    public int CompareTo(object obj)
    {
        if (obj == null) return 1;

        Node otherNode = obj as Node;
        if (otherNode != null)
        {
            return FScore.CompareTo(otherNode.FScore);
        }
        else throw new ArgumentException("Object is not a node!");
    }

    public override string ToString()
    {
        return Position.ToString() + " Score: " + FScore + " HASHCODE: " + GetHashCode();
    }

    public override bool Equals(object obj)
    {
       if(obj == null) return false;
        Node otherNode = obj as Node;
        if (otherNode != null)
        {
            return Position.x == otherNode.Position.x && Position.y == otherNode.Position.y;
        }
        return false;
    }

    public override int GetHashCode()
    {
        int x = (int)Position.x;
        int y = (int)Position.y;
        return (x * 9) + y;
    }

    public bool Equals(Node other)
    {
        if (other != null)
        {
            return Position.x == other.Position.x && Position.y == other.Position.y;
        }
        return false;
    }

    public bool Equals(Vector2 other)
    {
        return Position.x == other.x && Position.y == other.y;
    }
}