﻿using UnityEditor;

[CustomEditor(typeof(TileMovementWeight))]
public class MovementWeightInspector : Editor
{
    TileMovementWeight tmw;
    TileType typeSelected;

    void OnEnable()
    {
        tmw = (TileMovementWeight)target;
    }

    public override void OnInspectorGUI()
    {
        EditorGUILayout.BeginHorizontal();
        typeSelected = (TileType)EditorGUILayout.EnumPopup("Tile Type: ", typeSelected);
        tmw.WalkableTiles[typeSelected] = EditorGUILayout.FloatField(tmw.WalkableTiles[typeSelected]);
        EditorGUILayout.EndHorizontal();
    }
}
