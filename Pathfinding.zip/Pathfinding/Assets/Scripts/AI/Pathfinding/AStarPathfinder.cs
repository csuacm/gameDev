﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
public class AStarPathfinder : Pathfinder
{
    public int DEBUGLEVEL = 0;

    public int infiniteLoopCounter = 5000;
    public float diagMoveCost = 1.4f;

    private Node startVector;
    private Node destVector;

    public TileMovementWeight TileWeights;

    /// <summary>
    /// Set of all non-traversed/non-searched nodes in the current path
    /// </summary>
    private HashSet<Node> openListSlow = new HashSet<Node>();
    //private StablePriorityQueue<Node> openQueue; //This is WAYYYYY slower than hashset?

    /// <summary>
    /// Set of all traversed/searched nodes in the current path. These are only checked to ignore values when adding to the open list.
    /// </summary>
    private HashSet<Node> closedList = new HashSet<Node>();
    public override bool FindShortestPath(Vector2 from, Vector2 destination)
    {
        openListSlow = new HashSet<Node>();
        closedList = new HashSet<Node>();
        FinalPath = new LinkedList<Vector2>();

        if (DEBUGLEVEL == 3) Debug.Log("Moving from  " + from + "  to  " + destination);

        if (from.Equals(destination))
        {
            Debug.LogWarning("Destination is the same as the start vector");
            return false;
        }

        startVector = new Node(from);
        destVector = new Node(destination);

        int row = (int)destination.y;
        int col = (int)destination.x;

        if (!TileWeights.isWalkable((TileType)mapArray[row, col]))
        {
            if (DEBUGLEVEL == 2) Debug.LogWarning("Destination unreachable because " + mapArray[row, col] + " is not a walkable tile type");
            return false;
        }

        startVector.CostFromStart = 0.0f;
        startVector.FScore = EstimatedDistanceToEnd(startVector);
        openListSlow.Add(startVector);
        Node currentNode = startVector;
        bool pathFound = false;

        while (openListSlow.Count() > 0)
        {
            if(DEBUGLEVEL != 0)
            {
                infiniteLoopCounter--;
                if (infiniteLoopCounter == 0)
                {
                    Debug.LogError("infinite loop possible! breaking");
                    break;
                }
            }

            currentNode = openListSlow.Min();

            if (currentNode.Equals(destination))
            {
                //Found the end, break to plot path
                if (DEBUGLEVEL == 1) Debug.LogWarning("PATH FOUND!!");
                pathFound = true;
                break;
            }
            //we are checking this node, so remove it from the nodes to check
            closedList.Add(currentNode);
            openListSlow.Remove(currentNode);
            foreach (Node neighbor in NeighborNodes(currentNode))
            {
                if (!closedList.Contains(neighbor))
                {
                    if (!openListSlow.Contains(neighbor))
                    {
                        neighbor.CostFromStart = Mathf.Infinity;
                        neighbor.ParentNode = null;
                        neighbor.FScore = Mathf.Infinity;
                    }

                    float TotalCostFromStartToNeighbor = ComputeCost(currentNode, neighbor);

                    if (TotalCostFromStartToNeighbor < neighbor.CostFromStart)
                    {
                        if(openListSlow.Contains(neighbor))
                        {
                            openListSlow.Remove(neighbor);
                        }

                        neighbor.ParentNode = currentNode;
                        neighbor.CostFromStart = TotalCostFromStartToNeighbor;
                        neighbor.FScore = neighbor.CostFromStart + EstimatedDistanceToEnd(neighbor);

                        openListSlow.Add(neighbor);
                    }
                }
            }
            
            if (DEBUGLEVEL == 4) Debug.DrawLine(currentNode.ParentNode.Position, currentNode.Position,
                                                Color.red, 15.0f);
        }

        if (pathFound == true)
        {
            FinalPath = new LinkedList<Vector2>();
            while (currentNode != startVector)
            {
                currentNode.Position = new Vector2(currentNode.Position.x, -currentNode.Position.y);
                FinalPath.AddLast(currentNode.Position);
                currentNode = currentNode.ParentNode;
            }
            return true;
        }
        return false;
    }

    private IEnumerable<Node> NeighborNodes(Node startNode)
    {
        for (int xOffset = -1; xOffset <= 1; ++xOffset)
        {
            for (int yOffset = -1; yOffset <= 1; ++yOffset)
            {
                int checkX = (int)startNode.Position.x + xOffset;
                int checkY = (int)startNode.Position.y + yOffset;
                Node checkNode = new Node(checkX, checkY);

                if (isWalkableNode(checkNode) && !checkNode.Equals(startNode))
                {
                    yield return checkNode;
                }
            }
        }
    }

    private bool isWalkableNode(Node checkNode)
    {
        int row = (int)checkNode.Position.y;
        int col = (int)checkNode.Position.x;

        if (isOutsideArrayRange(checkNode)) return false;

        int tileNumber = mapArray[row, col];
        var tileType = (TileType)tileNumber;

        bool isWalkable = TileWeights.isWalkable(tileType);
        if (DEBUGLEVEL == -1)
        {
            Debug.Log(checkNode + ": " + tileNumber + "=>Walkable? : " + isWalkable);
            Debug.Log("TileType: " + tileType);
        }
        return isWalkable;
    }
    /// <summary>
    /// Cost from start to fromNode + MovementCost(fromNode, toNode)
    /// </summary>
    /// <param name="fromNode"></param>
    /// <param name="toNode"></param>
    /// <returns></returns>
    private float ComputeCost(Node fromNode, Node toNode)
    {
        return fromNode.CostFromStart + MovementCost(fromNode, toNode);
    }

    private bool isOutsideArrayRange(Node checkNode)
    {
        int row = (int)checkNode.Position.x;
        int col = (int)checkNode.Position.y;

        return (row < 0 || col < 0) ||
                row >= mapArray.GetLength(0) ||
                col >= mapArray.GetLength(1);
    }

    private float EstimatedDistanceToEnd(Node checkNode)
    {
        return Vector2.Distance(checkNode.Position, destVector.Position);
    }

    private float MovementCost(Node fromNode, Node toNode)
    {
        if(isDiagonal(fromNode,toNode))
        {
            return diagMoveCost;
        }
        else
        {
            return 1.0f;
        }
    }

    private bool isDiagonal(Node fromNode, Node toNode)
    {
        //if both row and column are nonzero, this is a diagonal vector movement
        return ((fromNode.Position.x - toNode.Position.x) != 0 &&
                (fromNode.Position.y - toNode.Position.y) != 0);
    }
}