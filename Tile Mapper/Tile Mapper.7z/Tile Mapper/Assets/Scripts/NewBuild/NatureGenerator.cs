﻿using UnityEngine;

public static class NatureGenerator{

    private static int[,] map;
    private static int height;
    private static int width;

    public static int[,] GenerateNature(int[,] m)
    {
        map = (int[,])m.Clone();
        height = map.GetLength(0);
        width = map.Length / map.GetLength(0);
        AddNature();
        return map;
    }

    private static void AddNature()
    {
        //Add trees and rocks
        for (int row = 2; row < height - 2; ++row)
        {
            for (int col = 2; col < width - 2; ++col)
            {
                //if there is no path roll for a chance to place a tree or rock
                if (map[row, col] == 2)
                {
                    int chance = Random.Range(1, 101);
                    //rock roll
                    if (chance >= 1 && chance <= 3)
                    {
                        map[row, col] = (int)TileType.Rock;
                    }
                    //tree roll
                    if (chance >= 4 && chance <= 8)
                    {
                        map[row, col] = (int)TileType.Tree;
                    }
                    //Bush
                    if (chance >= 9 && chance <= 13)
                    {
                        map[row, col] = (int)TileType.Bush;
                    }
                    //Logggggggguh
                    if (chance >= 14 && chance <= 14)
                    {
                        map[row, col] = (int)TileType.Log;
                    }
                }
            }
        }
    }
}
