﻿using System.Collections.Generic;
using UnityEngine;

public abstract class Pathfinder : MonoBehaviour
{
    internal int[,] mapArray { get; private set; }

    public void SetMap(int[,] map)
    {
        mapArray = map;
    }

    public LinkedList<Vector2> FinalPath { get; protected set; }
    /// <summary>
    /// Finds the shortest path between 2 vector points.
    /// </summary>
    /// <param name="from"></param>
    /// <param name="destination"></param>
    /// <returns>true if a path is found, false if not.</returns>
    public abstract bool FindShortestPath(Vector2 start, Vector2 end);
}
