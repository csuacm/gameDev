﻿using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class TileManager : MonoBehaviour {

    private Dictionary<int, List<TileSet>> tileDictionary;

    private static TileManager tileManager;

    //Find a way to populate the Dictionary give JSON files
    //Why do json files not show up in visual studio?
    //Test the populated Dictionary with a test map
    //Get the map working again
    //After that, get the load and save stuff worked out
    //Start working on town sets and additional scene props
    //Start thinking about how the eneimes/animals will be placed in the map

    public void Start()
    {
        tileDictionary = new Dictionary<int, List<TileSet>>();

        StreamReader sr = new StreamReader("C:\\Users\\cwlarson\\OneDrive\\Tile Mapper\\Assets\\Scripts\\NewBuild\\JsonFiles\\ForestRock.json");
        TileSet rock = JsonUtility.FromJson<TileSet>(sr.ReadLine());
        sr.Close();

        List<TileSet> tileSets = new List<TileSet>();
        tileSets.Add(rock);
        tileDictionary.Add(tileSets[0].TileKeyNumber,tileSets);

        Debug.Log(JsonUtility.ToJson(tileDictionary[8][0]));
    }
}
