﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;


[System.Serializable]
public class TileMovementWeight : MonoBehaviour
{
    public Dictionary<TileType, float> WalkableTiles = Enum.GetValues(typeof(TileType))
                                                           .Cast<TileType>()
                                                           .ToDictionary(k => k, v => 1.0f);

    void OnEnable()
    {
        WalkableTiles = Enum.GetValues(typeof(TileType))
                            .Cast<TileType>()
                            .ToDictionary(k => k, v => 1.0f);

        WalkableTiles[TileType.Tree] = 0.0f;
        WalkableTiles[TileType.Unreachable] = 0.0f;
        WalkableTiles[TileType.Boarder] = 0.0f;
    }

    public bool isWalkable(TileType type)
    {
        if((type & TileType.Path) != 0) type = TileType.Path;
        if(!WalkableTiles.ContainsKey(type))
        {
            Debug.Log(type + " is not a valid tiletype!");
            return false;
        }
        return WalkableTiles[type] != 0.0;
    }

    public float MovementWeight(TileType type)
    {
        if ((type & TileType.Path) != 0) type = TileType.Path;
        if (!WalkableTiles.ContainsKey(type))
        {
            Debug.Log(type + " is not a valid tiletype!");
            return 0.0f;
        }
        return WalkableTiles[type];
    }
}