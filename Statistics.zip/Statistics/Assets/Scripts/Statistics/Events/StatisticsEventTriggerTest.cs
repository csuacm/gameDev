﻿using UnityEngine;
using UnityEngine.Events;

public class StatisticsEventTriggerTest : MonoBehaviour
{
    public UnityEvent UpdateEvent;
    void Update()
    {
        if (Input.GetKeyDown("u"))
        {
            UpdateEvent.Invoke();
        }
    }
}

