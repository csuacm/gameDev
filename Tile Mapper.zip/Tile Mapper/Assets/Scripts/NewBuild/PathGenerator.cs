﻿using UnityEngine;

public static class PathGenerator{

    private static int[,] map;
    private static int[] midpoint = new int[2];
    private static int height;
    private static int width;

    //Box holds high and low values for probability roles for the path generation
    struct Box
    {
        public int low;
        public int high;
        public Box(int l, int h)
        {
            low = l;
            high = h;
        }
    }

    public static int[,] GeneratePath(int[,] m, int thickness, bool n, bool e, bool s, bool w)
    {
        if (!n && !e && !s && !w)//no gates are active, return m
            return m;
        else
            map = (int[,])m.Clone();//copy 2d array

        //set a height and width
        height = map.GetLength(0);
        width = map.Length / map.GetLength(0);

        //make a midpoint to connect to
        SetMidPoint();

        if (n)//if north gate is active
        {
            int rand = Random.Range(thickness, width - thickness);
            int[] start = new int[] { 0 , rand };
            ConnectGate(start);
        }
        if (e)//if east gate is active
        {
            int rand = Random.Range(thickness, height - thickness);
            int[] start = new int[] { rand, width - 1};
            ConnectGate(start);
        }
        if (s)//if south gate is active
        {
            int rand = Random.Range(thickness, width - thickness);
            int[] start = new int[] { (height - 1), rand };
            ConnectGate(start);
        }
        if (w)//if west gate is active
        {
            int rand = Random.Range(thickness, height - thickness);
            int[] start = new int[] { rand, 0 };
            ConnectGate(start);
        }

        //Make lanes/canyon style
        PathWays(thickness);

        PathFormate();

        BoarderControl();

        //return the map with generated path(s)
        return map;
    }

    private static void SetMidPoint()
    {
        midpoint[0] = (height / 2) + Random.Range(-(height / 4), height / 4);
        midpoint[1] = (width / 2) + Random.Range(-(width / 4), width / 4);
    }

    //uses start point to connect to the midpoint
    private static void ConnectGate(int[] start)
    {
        Box[,] move = new Box[3, 3];

        bool connected = false;
        while (!connected)
        {
            //update move
            int R = start[0] - midpoint[0];
            int C = start[1] - midpoint[1];
            //clear past move
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Box b = new Box(0, 0);
                    move[i, j] = b;
                }
            }
            //Assign Box probability roles
            AssignBoxProbability(move, R, C);

            //check validity of move
            move = UpdateMoveBox(move, start);

            //check if end is reached
            if (IsDone(start, midpoint))
                break;

            //make move
            start = MakeMove(start, move);

            //check if end is reached
            connected = IsDone(start, midpoint);
        }
 
    }

    private static Box[,] AssignBoxProbability(Box[,] move, int R, int C)
    {
        //RANGE VALUES------------------------------------------------------------------------------------------
        int highChance = 60;
        int midChanceLow = 61;
        int midChanceHigh = 75;
        int midChanceLow1 = 76;
        int midChanceHigh1 = 85;
        int lowChanceLow = 86;
        int lowChanceHigh = 95;
        int lowChanceLow1 = 96;
        int lowChanceHigh1 = 100;
        //set potenial moves
        if (R < 0)//Below
        {
            if (C == 0)//same col 
            {
                move[2, 1].high = highChance;//D
                move[2, 0].low = midChanceLow; move[2, 0].high = midChanceHigh;//DL
                move[2, 2].low = midChanceLow1; move[2, 2].high = midChanceHigh1;//DR
                move[1, 0].low = lowChanceLow; move[1, 0].high = lowChanceHigh;//L
                move[1, 2].low = lowChanceLow1; move[1, 2].low = lowChanceHigh1;//R
            }
            else if (C > 0)//down left
            {
                move[2, 0].high = highChance;//DL
                move[2, 1].low = midChanceLow; move[2, 1].high = midChanceHigh;//D
                move[1, 0].low = midChanceLow1; move[1, 0].high = midChanceHigh1;//L
                move[0, 0].low = lowChanceLow; move[0, 0].high = lowChanceHigh;//UL
                move[2, 2].low = lowChanceLow1; move[2, 2].high = lowChanceHigh1;//DR
            }
            else//down right
            {
                move[2, 2].high = highChance;//DR
                move[2, 1].low = midChanceLow; move[2, 1].high = midChanceHigh;//D
                move[1, 2].low = midChanceLow1; move[1, 2].high = midChanceHigh1;//R
                move[2, 0].low = lowChanceLow; move[2, 0].high = lowChanceHigh;//DL
                move[0, 2].low = lowChanceLow1; move[0, 2].high = lowChanceHigh1;//UR
            }
        }
        else if (R > 0)//Above
        {
            if (C == 0)//same col 
            {
                move[0, 1].high = highChance;//U
                move[0, 0].low = midChanceLow; move[0, 0].high = midChanceHigh;//UL
                move[0, 2].low = midChanceLow1; move[0, 2].high = midChanceHigh1;//UR
                move[1, 0].low = lowChanceLow; move[1, 0].high = lowChanceHigh;//L
                move[1, 2].low = lowChanceLow1; move[1, 2].high = lowChanceHigh1;//R
            }
            else if (C > 0)//up left
            {
                move[0, 0].high = highChance;//UL
                move[0, 1].low = midChanceLow; move[0, 1].high = midChanceHigh;//U
                move[1, 0].low = midChanceLow1; move[1, 0].high = midChanceHigh1;//L
                move[2, 0].low = lowChanceLow; move[2, 0].high = lowChanceHigh;//DL
                move[0, 2].low = lowChanceLow1; move[0, 2].high = lowChanceHigh1;//UR
            }
            else//up right
            {
                move[0, 2].high = highChance;//UR
                move[0, 1].low = midChanceLow; move[0, 1].high = midChanceHigh;//U
                move[1, 2].low = midChanceLow1; move[1, 2].high = midChanceHigh1;//R
                move[0, 0].low = lowChanceLow; move[0, 0].high = lowChanceHigh;//UL
                move[2, 2].low = lowChanceLow1; move[2, 2].high = lowChanceHigh1;//DR
            }
        }
        else//R == 0
        {
            if (C > 0)//Left
            {
                move[1, 0].high = highChance;//L
                move[0, 0].low = midChanceLow; move[0, 0].high = midChanceHigh;//UL
                move[2, 0].low = midChanceLow1; move[2, 0].high = midChanceHigh1;//DL
                move[0, 1].low = lowChanceLow; move[0, 1].high = lowChanceHigh;//U
                move[2, 1].low = lowChanceLow1; move[2, 1].high = lowChanceHigh1;//D
            }
            else//Right
            {
                move[1, 2].high = highChance;//R
                move[0, 2].low = midChanceLow; move[0, 2].high = midChanceHigh;//UR
                move[2, 2].low = midChanceLow1; move[2, 2].high = midChanceHigh1;//DR
                move[0, 1].low = lowChanceLow; move[0, 1].high = lowChanceHigh;//U
                move[2, 1].low = lowChanceLow1; move[2, 1].high = lowChanceHigh1;//D
            }
        }
        return move;
    }

    private static Box[,] UpdateMoveBox(Box[,] move, int[] start)
    {
        if (start[0] == 0 || start[0] == (height - 1))//no horizontal 
        {
            move[1, 0].low = 0; move[1, 0].high = 0;//L
            move[1, 2].low = 0; move[1, 2].high = 0;//R
            if (start[0] == 0)
            {
                move[0, 0].low = 0; move[0, 0].high = 0;//UL
                move[0, 2].low = 0; move[0, 2].high = 0;//UR
            }
            else
            {
                move[2, 0].low = 0; move[2, 0].high = 0;//DL
                move[2, 2].low = 0; move[2, 2].high = 0;//DR
            }

        }
        if (start[1] == 0 || start[1] == (width - 1))//no vertical
        {
            move[0, 1].low = 0; move[0, 1].high = 0;//U
            move[2, 1].low = 0; move[2, 1].high = 0;//D
            if (start[1] == 0)
            {
                move[0, 0].low = 0; move[0, 0].high = 0;//UL
                move[2, 0].low = 0; move[2, 0].high = 0;//DL
            }
            else
            {
                move[0, 2].low = 0; move[0, 2].high = 0;//UR
                move[2, 2].low = 0; move[2, 2].high = 0;//DR
            }
        }
        if (start[0] == 1)//near top then no up movement
        {
            move[0, 0].low = 0; move[0, 0].high = 0; //UL
            move[0, 1].low = 0; move[0, 1].high = 0; //U
            move[0, 2].low = 0; move[0, 2].high = 0; //UR
        }
        if (start[0] == (height - 2))//near bottom then no down
        {
            move[2, 0].low = 0; move[2, 0].high = 0; //DL
            move[2, 1].low = 0; move[2, 1].high = 0; //D
            move[2, 2].low = 0; move[2, 2].high = 0; //DR
        }
        if (start[1] == 1)//near left then no left
        {
            move[0, 0].low = 0; move[0, 0].high = 0;//UL
            move[1, 0].low = 0; move[1, 0].high = 0;//L
            move[2, 0].low = 0; move[2, 0].high = 0;//DL
        }
        if (start[1] == width - 2)//near right then no right
        {
            move[0, 2].low = 0; move[0, 2].high = 0;//UR
            move[1, 2].low = 0; move[1, 2].high = 0;//R
            move[2, 2].low = 0; move[2, 2].high = 0;//DR
        }

        return move;
    }

    private static bool IsDone(int[] start, int[] end)
    {
        if (Mathf.Abs(start[0] - end[0]) == 1 || Mathf.Abs(start[0] - end[0]) == 0)
        {
            if (Mathf.Abs(start[1] - end[1]) == 1)
                return true;
        }

        if (Mathf.Abs(start[1] - end[1]) == 1 || Mathf.Abs(start[1] - end[1]) == 0)
        {
            if (Mathf.Abs(start[0] - end[0]) == 1)
                return true;
        }
        return false;
    }

    private static int[] MakeMove(int[] start, Box[,] move)
    {
        bool moveMade = false;
        while (!moveMade)
        {
            int moveNumber = Random.Range(1, 101);
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (move[i, j].low <= moveNumber && move[i, j].high >= moveNumber)
                    {
                        if (start[0] >= 0 && start[0] < height && start[1] >= 0 && start[1] < width)
                        {
                            start[0] += i - 1;
                            start[1] += j - 1;
                            map[start[0], start[1]] = 1;
                            moveMade = true;
                            break;
                        }
                    }
                }
            }
        }
        //Add side path
        for (int i = start[0] - 1; i < start[0] + 2; ++i)
        {
            for (int j = start[1] - 1; j < start[1] + 2; ++j)
            {
                    map[i, j] = 1;
            }
        }
        return start;
    }

    private static void PathWays(int lane)
    {
        for (int i = 0; i < height; ++i)
        {
            for (int j = 0; j < width; ++j)
            {
                if (map[i, j] == (int)TileType.Path)
                {
                    int rand = Random.Range(1, (lane + 2));
                    for (int row = i - rand; row <= i + rand; ++row)
                    {
                        for (int col = j - rand; col <= j + rand; ++col)
                        {
                            //If invalid check, skip
                            if (row >= 0 && row < height && col >= 0 && col < width)
                            {
                                //Handle corner cases
                                if (row == i - rand && col == j - rand)//Up Left
                                {
                                    if (map[row, col] != (int)TileType.Path && map[row, col] != (int)TileType.DefaultTile)
                                        map[row, col] = (int)TileType.Boarder;
                                }
                                else if (row == i - rand && col == j + rand)//Up Right
                                {
                                    if (map[row, col] != (int)TileType.Path && map[row, col] != (int)TileType.DefaultTile)
                                        map[row, col] = (int)TileType.Boarder;
                                }
                                else if (row == i + rand && col == j - rand)//Down Left
                                {
                                    if (map[row, col] != (int)TileType.Path && map[row, col] != (int)TileType.DefaultTile)
                                        map[row, col] = (int)TileType.Boarder;
                                }
                                else if (row == i + rand && col == j + rand)//Down Right
                                {
                                    if (map[row, col] != (int)TileType.Path && map[row, col] != (int)TileType.DefaultTile)
                                        map[row, col] = (int)TileType.Boarder;
                                }
                                //Handle sides and replace overlapping corners with sides
                                else if (row != i - rand && row != i + rand && col == j - rand)//Left
                                {
                                    if (map[row, col] != (int)TileType.Path && map[row, col] != (int)TileType.DefaultTile)
                                        map[row, col] = (int)TileType.Boarder;
                                }
                                else if (row != i - rand && row != i + rand && col == j + rand)//Right
                                {
                                    if (map[row, col] != (int)TileType.Path && map[row, col] != (int)TileType.DefaultTile)
                                        map[row, col] = (int)TileType.Boarder;
                                }
                                else if (row == i - rand && col != j - rand && col != j + rand)//Up
                                {
                                    if (map[row, col] != (int)TileType.Path && map[row, col] != (int)TileType.DefaultTile)
                                        map[row, col] = (int)TileType.Boarder;
                                }
                                else if (row == i + rand && col != j + rand && col != j + rand)//Down
                                {
                                    if (map[row, col] != (int)TileType.Path && map[row, col] != (int)TileType.DefaultTile)
                                        map[row, col] = (int)TileType.Boarder;
                                }
                                //Set middle to grass
                                if (row > (i - rand) && row < (i + rand) && col > (j - rand) && col < (j + rand))
                                {
                                    if (map[row, col] != (int)TileType.Path)
                                        map[row, col] = (int)TileType.DefaultTile;
                                }
                            }

                        }
                    }
                }
            }
        }
    }

    private static void PathFormate()
    {
        for(int row = 0; row < height; ++row)
        {
            for(int col = 0; col < width; ++col)
            {
                if (map[row, col] != 1) continue;
                int counter = 0;
                for(int i = row - 1; i <= row + 1; ++i)
                {
                    for(int j = col - 1; j <= col + 1; ++j)
                    {
                        if(i >= 0 && i < height && j >= 0 && j < width)
                        {
                            if((map[i, j] & (int)TileType.Path) == 0 && !(i == row && j == col))
                            {
                                map[row, col] += 2 << counter;
                            }
                            
                        }
                        if (!(i == row && j == col)) counter++;
                    }
                }
            }
        }
    }

    private static void BoarderControl()
    {
        for (int i = 0; i < height; ++i)
        {
            if((map[i, 0] & 1) != 1 && map[i, 0] != (int)TileType.Unreachable)
            {
                map[i, 0] = (int)TileType.Boarder;
            }
            if ((map[i, width - 1] & 1) != 1 && map[i, width - 1] != (int)TileType.Unreachable)
            {
                map[i, width - 1] = (int)TileType.Boarder;
            }
        }
        for (int i = 0; i < width; ++i)
        {
            if ((map[0, i] & 1) != 1 && map[0, i] != (int)TileType.Unreachable)
            {
                map[0, i] = (int)TileType.Boarder;
            }
            if ((map[height - 1, i] & 1) != 1 && map[height - 1, i] != (int)TileType.Unreachable)
            {
                map[height - 1, i] = (int)TileType.Boarder;
            }
        }
    }
}
