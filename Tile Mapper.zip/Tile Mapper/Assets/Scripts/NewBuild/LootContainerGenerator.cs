﻿using UnityEngine;

public static class LootContainerGenerator
{
    private static int[,] map;
    private static int height;
    private static int width;


    public static int[,] GenerateLootContainers(int[,] m)
    {
        map = m;
        height = map.GetLength(0);
        width = map.Length / map.GetLength(0);


        for (int row = 0; row < height; ++row)
        {
            for (int col = 0; col < width; ++col)
            {
                if(map[row, col] == (int)TileType.DefaultTile)
                {
                    //check if the path is wide enough to place container (the eight tiles around the path tile)
                    int counter = 0;
                    for(int i = row - 1; i <= row + 1; ++i)
                    {
                        for (int j = col - 1; j <= col + 1; ++j)
                        {
                            if (i >= 0 && i < height && j >= 0 && j < width)
                            {
                                if(map[i, j] == (int)TileType.DefaultTile)
                                {
                                    counter++;
                                }
                            }
                        }
                    }
                    //place a chest
                    if(counter >= 9)
                    {
                        if(Random.Range(1, 1001) >= 995)
                            map[row, col] = (int)TileType.Chest;
                    }
                    //place a barrel 
                    if(counter >= 4 && counter < 7)
                    {
                        if (Random.Range(1, 1001) >= 980)
                            map[row, col] = (int)TileType.Barrel;
                    }
                }
            }
        }
        return map;
    }
}
