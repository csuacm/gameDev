﻿using UnityEngine;
using System.IO;

public class MapGenerator : MonoBehaviour {

    private int[,] map;

    //FIXME: Return these to private after testing
    public MapTypes mapTypes;
    public int height = 25;
    public int width = 25;
    public int thickness = 10;
    public bool northGate;
    public bool eastGate;
    public bool southGate;
    public bool westGate;

    public void Start()
    {
        InstantiateMap(height, width);
        CreateMap();
        SaveMap("C:\\Users\\cwlarson\\OneDrive\\Tile Mapper\\Assets\\Scripts\\NewBuild\\", "NewTest.txt");

        int[,] testMap = { { 2, 2, 2 }, { 2, 2, 2 }, { 2, 2, 2 }, { 64, 64, 64 },
                           { 8, 8, 8 }, { 8, 8, 8 }, { 8, 8, 8 }, { 8, 8, 8 },
                           { 32, 32, 32 }, { 32, 32, 32 }, { 32, 32, 32 }, { 32, 32, 32 },
                           { 16, 16, 16 }, { 16, 16, 16 }, { 16, 16, 16 }, { 1, 1, 15 }};

        var tileMapper = new TileMapper(mapTypes, testMap);
        tileMapper.MapTiles();
    }

    private void InstantiateMap(int h, int w)
    {
        map = new int[h, w];
        for (int row = 0; row < h; ++row)
        {
            for (int col = 0; col < w; ++col)
            {
                map[row, col] = 0;
            }
        }
    }

    public void CreateMap()
    {
        map = PathGenerator.GeneratePath(map, thickness, northGate, eastGate, southGate, westGate);
        map = NatureGenerator.GenerateNature(map);
    }

    public void SetSize(int h, int w, int t)
    {
        this.height = h;
        this.width = w;
        this.thickness = t;
    }

    public void SetMapType(MapTypes m)
    {
        this.mapTypes = m;
    }

    public int[,] GetCopyOfMap()
    {
        return (int[,])map.Clone();
    }

    //Make the size of the map in the file
    public void SaveMap(string filepath, string filename)
    {
        var streamWriter = new StreamWriter(@filepath + filename);


        for (int i = 0; i < height; ++i)
        {
            for (int j = 0; j < width; ++j)
            {
                streamWriter.Write(map[i, j] + " ");
            }
            streamWriter.WriteLine();
        }

        streamWriter.Close();
    }

    //Make the size of the map in the file
    public void LoadMap(string filepath, string filename)
    {
        StreamReader sr = new StreamReader(@filepath + filename);
        string[] s = new string[height];
        for (int i = 0; i < height; ++i)
        {
            s[i] = sr.ReadLine();
        }
        int[] iray = new int[width];
        for (int i = 0; i < height; ++i)
        {
            string[] t = s[i].Split(' ');
            for (int j = 0; j < t.Length - 1; ++j)
            {
                iray[j] = System.Convert.ToInt32(t[j]);
                map[i, j] = iray[j];
            }

        }
    }

    public MapTypes GetMapType()
    {
        return mapTypes;
    }

    public void setNorthGate(bool b)
    {
        northGate = b;
    }

    public void setEastGate(bool b)
    {
        eastGate = b;
    }

    public void setSouthGate(bool b)
    {
        southGate = b;
    }

    public void setWestGate(bool b)
    {
        westGate = b;
    }
}
