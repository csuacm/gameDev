﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
public class ThetaStarPathfinder : Pathfinder
{
    public int DEBUGLEVEL = 0;

    public int infiniteLoopCounter = 5000;

    private Node startNode;
    private Node destNode;

    public TileMovementWeight TileWeights;

    /// <summary>
    /// Set of all non-traversed/non-searched nodes in the current path
    /// </summary>
    private HashSet<Node> openListSlow = new HashSet<Node>();

    /// <summary>
    /// Set of all traversed/searched nodes in the current path. These are only checked to ignore values when adding to the open list.
    /// </summary>
    private HashSet<Node> closedList = new HashSet<Node>();

    public override bool FindShortestPath(Vector2 from, Vector2 destination)
    {
        openListSlow = new HashSet<Node>();
        closedList = new HashSet<Node>();
        FinalPath = new LinkedList<Vector2>();


        if (from.Equals(destination))
        {
            Debug.LogWarning("Destination is the same as the start vector");
            return false;
        }

        startNode = new Node(from);
        destNode = new Node(destination);

        int row = (int)destination.y;
        int col = (int)destination.x;

        if (!TileWeights.isWalkable((TileType)mapArray[row, col])) return false;

        startNode.CostFromStart = 0.0f;
        startNode.FScore = EstimatedDistanceToEnd(startNode);
        startNode.ParentNode = startNode;

        openListSlow.Add(startNode);
        Node currentNode = startNode;
        bool pathFound = false;

        while (openListSlow.Count() > 0)
        {
            if(DEBUGLEVEL != 0)
            {
                infiniteLoopCounter--;
                if (infiniteLoopCounter == 0)
                {
                    Debug.LogError("infinite loop possible! breaking");
                    break;
                }
            }

            currentNode = openListSlow.Min();
            
            SetVertex(currentNode);

            if (currentNode.Equals(destination))
            {
                //Found the end, break to plot path
                pathFound = true;
                break;
            }
            closedList.Add(currentNode);
            openListSlow.Remove(currentNode);
            //we are checking this node, so remove it from the nodes to check

            foreach (Node neighbor in NeighborNodes(currentNode))
            {
                if (!closedList.Contains(neighbor))
                {
                    if (!openListSlow.Contains(neighbor))
                    {
                        neighbor.CostFromStart = Mathf.Infinity;
                        neighbor.ParentNode = currentNode.ParentNode;
                        neighbor.FScore = Mathf.Infinity;
                    }

                    if (DEBUGLEVEL == -4)
                        Debug.DrawLine(new Vector2(currentNode.ParentNode.Position.x,
                                                  -currentNode.ParentNode.Position.y),
                                       new Vector2(neighbor.Position.x,
                                                  -neighbor.Position.y ), Color.blue, 3.0f);

                    UpdateVertex(currentNode, neighbor);
                }
            }
            
        }

        if (pathFound == true)
        {
            if(setFinalPath(currentNode) == true) return true;
        }
        return false;
    }
    /// <summary>
    /// Sets this vertex's new parent if the current parent is not within line of sight, otherwise does nothing
    /// </summary>
    /// <param name="current"></param>
    private void SetVertex(Node current)
    {
        if (!lineOfSight(current.ParentNode, current))
        {
            var visibleMinimumNeighbors = closedList.Where(node => lineOfSight(current, node) && isWalkableNode(node));

            if(visibleMinimumNeighbors != null && visibleMinimumNeighbors.Count() > 0)
            {           
                current.ParentNode = visibleMinimumNeighbors.Min();
                current.CostFromStart = current.ParentNode.CostFromStart
                                      + Vector2.Distance(current.ParentNode.Position, current.Position);

                current.FScore = current.CostFromStart + EstimatedDistanceToEnd(current);
            }
        }
    }

    private bool lineOfSight(Node fromNode, Node toNode)
    {
        var fromVector = new Vector2(fromNode.Position.x, -fromNode.Position.y);
        var toVector = new Vector2(toNode.Position.x, -toNode.Position.y);

        var impassableTerrainMask = 1 << 13;

        var hit = Physics2D.LinecastNonAlloc(fromVector, toVector, new RaycastHit2D[1], impassableTerrainMask);
        //Debug.DrawLine(fromVector, toVector, Color.cyan, 4.0f, false);

        if(hit == 0)
        {
            return true;
        }
        return false;
    }

    private IEnumerable<Node> NeighborNodes(Node currentNode)
    {
        for (int xOffset = -1; xOffset <= 1; ++xOffset)
        {
            for (int yOffset = -1; yOffset <= 1; ++yOffset)
            {
                int checkX = (int)currentNode.Position.x + xOffset;
                int checkY = (int)currentNode.Position.y + yOffset;
                Node neighbor = new Node(checkX, checkY);

                if (isWalkableNode(neighbor))
                {
                    yield return neighbor;
                }
            }
        }
    }

    private bool isWalkableNode(Node checkNode)
    {
        int col = (int)checkNode.Position.x;
        int row = (int)checkNode.Position.y;
        
        if (isOutsideArrayRange(checkNode)) return false;

        int tileNumber = mapArray[row, col];
        var tileType = (TileType)tileNumber;

        bool isWalkable = TileWeights.isWalkable(tileType);
        return isWalkable;
    }
    /// <summary>
    /// Cost from start to fromNode + MovementCost(fromNode, toNode)
    /// </summary>
    /// <param name="fromNode"></param>
    /// <param name="toNode"></param>
    /// <returns></returns>
    private float ComputeCost(Node s, Node sPrime)
    {
        float gOld = sPrime.CostFromStart;
        //this is the lazy theta* part: ASSUME this node will have line of sight
        //to its parent's node
        float gNew = s.ParentNode.CostFromStart + 
                     Vector2.Distance(s.ParentNode.Position,
                                      sPrime.Position);

        if(gNew < gOld)
        {
            sPrime.ParentNode = s.ParentNode;
            sPrime.CostFromStart = gNew;
        }
        return gNew;
    }

    private void UpdateVertex(Node s, Node sPrime)
    {
        float gOld = sPrime.CostFromStart;
        float gNew = ComputeCost(s, sPrime);
        if (gNew < gOld)
        {
            if (openListSlow.Contains(sPrime))
            {
                openListSlow.Remove(sPrime);
            }

            sPrime.FScore = gNew + EstimatedDistanceToEnd(sPrime);

            openListSlow.Add(sPrime);
        }
    }

    private bool isOutsideArrayRange(Node checkNode)
    {
        int row = (int)checkNode.Position.x;
        int col = (int)checkNode.Position.y;

        return (row < 0 || col < 0) ||
                row >= mapArray.GetLength(0) ||
                col >= mapArray.GetLength(1);
    }

    private float EstimatedDistanceToEnd(Node checkNode)
    {
        return Vector2.Distance(checkNode.Position, destNode.Position);
    }

    private bool setFinalPath(Node goalNode)
    {
        FinalPath = new LinkedList<Vector2>();

        while (goalNode != startNode)
        {
            goalNode.Position = new Vector2(goalNode.Position.x, -goalNode.Position.y);
            FinalPath.AddFirst(goalNode.Position);
            goalNode = goalNode.ParentNode;

            if (DEBUGLEVEL != 0)
            {
                infiniteLoopCounter--;
                if (infiniteLoopCounter <= 0)
                {
                    Debug.LogError("Infinite loop condition in final path code");
                    return false;
                }
            }
        }
        FinalPath.AddFirst(new Vector2(startNode.Position.x, -startNode.Position.y));
        return true;
    }
}