﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;


public class TileMapperOld
{

    //No map smaller than 25x25, please
    //No map larger than 256x256, please
    public const int height = 64;
    public const int width = 64;
    public int lane = 15;
    public int boarder = 1;//Controls the size of the boarder

    private static int[,] generatedMap = new int[height, width];

    public enum eMapStyle { Forest, Cave, Desert };

    //Box holds high and low values for probability roles for the path generation
    struct Box
    {
        public int low;
        public int high;
        public Box(int l, int h)
        {
            low = l;
            high = h;
        }
    }

    //To change the number that represents the path, change this variable
    int pathNumber = 1;

    //------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //Takes the Style of the map and makes a map based on that style
    //Also takes a 4 bit number to add gates to the map(WestSouthEastNorth)
    //TODO: Make more paramaters to define the maps uniqueness
    public void GenerateMap(eMapStyle mapStyle, int bitGates)
    {

        switch (mapStyle)
        {
            case eMapStyle.Forest:
                //Make the map blocks
                for (int i = 0; i < height; ++i)
                {
                    for (int j = 0; j < width; ++j)
                    {
                        generatedMap[i, j] = 0;
                    }
                }
                //Add path gates
                if (bitGates == 0)
                {
                    Debug.Log("Must have a gate!");
                    return;
                }

                int mask = 1;
                int[] northGate = new int[2];
                int[] eastGate = new int[2];
                int[] southGate = new int[2];
                int[] westGate = new int[2];
                //Make a random mid point

                int[] mid = new int[2];
                mid[0] = (height / 2) + Random.Range(-(height / 4), (height / 4));
                mid[1] = (width / 2) + Random.Range(-(width / 4), (width / 4));

                for (int i = 0; i < 4; ++i)
                {

                    //this number represents the "middle" of the map that the gate paths lead to
                    generatedMap[mid[0], mid[1]] = pathNumber;

                    if ((mask & bitGates) != 0)
                    {
                        int randomNumber;
                        switch (i)
                        {
                            case 0://North
                                randomNumber = Random.Range(lane, width - lane);
                                generatedMap[0, randomNumber] = pathNumber;
                                generatedMap[0, randomNumber - 1] = pathNumber;
                                generatedMap[0, randomNumber + 1] = pathNumber;
                                northGate[0] = 0;
                                northGate[1] = randomNumber;
                                ConnectGate(northGate, mid);
                                break;
                            case 1://East
                                randomNumber = Random.Range(lane, height - lane);
                                generatedMap[randomNumber, width - 1] = pathNumber;
                                generatedMap[randomNumber - 1, width - 1] = pathNumber;
                                generatedMap[randomNumber + 1, width - 1] = pathNumber;
                                eastGate[0] = randomNumber;
                                eastGate[1] = width - 1;
                                ConnectGate(eastGate, mid);
                                break;
                            case 2://South
                                randomNumber = Random.Range(lane, width - lane);
                                generatedMap[height - 1, randomNumber] = pathNumber;
                                generatedMap[height - 1, randomNumber - 1] = pathNumber;
                                generatedMap[height - 1, randomNumber + 1] = pathNumber;
                                southGate[0] = height - 1;
                                southGate[1] = randomNumber;
                                ConnectGate(southGate, mid);
                                break;
                            case 3://West
                                randomNumber = Random.Range(lane, height - lane);
                                generatedMap[randomNumber, 0] = pathNumber;
                                generatedMap[randomNumber - 1, 0] = pathNumber;
                                generatedMap[randomNumber + 1, 0] = pathNumber;
                                westGate[0] = randomNumber;
                                westGate[1] = 0;
                                ConnectGate(westGate, mid);
                                break;
                        }
                    }
                    mask <<= 1;
                }

                //Enclose the path
                PathWays(lane);

                //Add trees and rocks
                AddNature();

                //Make a boarder
                SetBoarder();
                break;
            case eMapStyle.Cave:

                break;
            case eMapStyle.Desert:

                break;
        }
    }

    private void PathWays(int lane)
    {
        for(int i = 0; i < height; ++i)
        {
            for(int j = 0; j < width; ++j)
            {
                if(generatedMap[i, j] == 1)
                {
                    int rand = Random.Range(1, (lane + 2));
                    for (int row = i - rand; row <= i + rand; ++row)
                    {
                        for (int col = j - rand; col <= j + rand; ++col)
                        {
                            //If invalid check, skip
                            if (row >= 0 && row < height && col >= 0 && col < width)
                            {
                                //Handle corner cases
                                if (row == i - rand && col == j - rand)//Up Left
                                {
                                    if (generatedMap[row, col] != 1 && generatedMap[row, col] != 2)
                                        generatedMap[row, col] = 8;
                                }
                                else if (row == i - rand && col == j + rand)//Up Right
                                {
                                    if (generatedMap[row, col] != 1 && generatedMap[row, col] != 2)
                                        generatedMap[row, col] = 8;
                                }
                                else if (row == i + rand && col == j - rand)//Down Left
                                {
                                    if (generatedMap[row, col] != 1 && generatedMap[row, col] != 2)
                                        generatedMap[row, col] = 8;
                                }
                                else if (row == i + rand && col == j + rand)//Down Right
                                {
                                    if (generatedMap[row, col] != 1 && generatedMap[row, col] != 2)
                                        generatedMap[row, col] = 8;
                                }
                                //Handle sides and replace overlapping corners with sides
                                else if (row != i - rand && row != i + rand && col == j - rand)//Left
                                {
                                    if (generatedMap[row, col] != 1 && generatedMap[row, col] != 2)
                                        generatedMap[row, col] = 8;
                                }
                                else if (row != i - rand && row != i + rand && col == j + rand)//Right
                                {
                                    if (generatedMap[row, col] != 1 && generatedMap[row, col] != 2)
                                        generatedMap[row, col] = 8;
                                }
                                else if (row == i - rand && col != j - rand && col != j + rand)//Up
                                {
                                    if (generatedMap[row, col] != 1 && generatedMap[row, col] != 2)
                                        generatedMap[row, col] = 8;
                                }
                                else if (row == i + rand && col != j + rand && col != j + rand)//Down
                                {
                                    if (generatedMap[row, col] != 1 && generatedMap[row, col] != 2)
                                        generatedMap[row, col] = 8;
                                }
                                //Set middle to grass
                                if (row > (i - rand) && row < (i + rand) && col > (j - rand) && col < (j + rand))
                                {
                                    if (generatedMap[row, col] != 1)
                                        generatedMap[row, col] = 2;
                                }
                            }
                            
                        }
                    }
                }
            }
        }
    }

    private void AddNature()
    {
        //Add trees and rocks
        for (int row = 2; row < height - 2; ++row)
        {
            for (int col = 2; col < width - 2; ++col)
            {
                //if there is no path roll for a chance to place a tree or rock
                if (generatedMap[row, col] == 2)
                {
                    int chance = Random.Range(1, 101);
                    //rock roll
                    if (chance >= 1 && chance <= 3)
                    {
                        generatedMap[row, col] = 4;
                    }
                    //tree roll
                    if (chance >= 4 && chance <= 8)
                    {
                        generatedMap[row, col] = 3;
                    }
                    //Bush
                    if(chance >= 9 && chance <= 13)
                    {
                        generatedMap[row, col] = 5;
                    }
                    //Stick
                    if(chance >= 14 && chance <= 14)
                    {
                        generatedMap[row, col] = 6;
                    }
                }
            }
        }
    }

    private void ConnectGate(int[] start, int[] end)
    {

        bool connected = false;
        Box[,] move = new Box[3, 3];
        while (!connected)
        {
            //update move
            int R = start[0] - end[0];
            int C = start[1] - end[1];
            //clear past move
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Box b = new Box(0, 0);
                    move[i, j] = b;
                }
            }
            //Assign Box probability roles
            AssignBoxProbability(move, R, C);

            //check validity of move
            move = UpdateMoveBox(move, start);

            //make move
            start = MakeMove(start, move);

            //check if end is reached
            connected = IsDone(start, end);


        }
    }

    private Box[,] AssignBoxProbability(Box[,] move, int R, int C)
    {
        //RANGE VALUES------------------------------------------------------------------------------------------
        int highChance = 60;
        int midChanceLow = 61;
        int midChanceHigh = 75;
        int midChanceLow1 = 76;
        int midChanceHigh1 = 85;
        int lowChanceLow = 86;
        int lowChanceHigh = 95;
        int lowChanceLow1 = 96;
        int lowChanceHigh1 = 100;
        //set potenial moves
        if (R < 0)//Below
        {
            if (C == 0)//same col 
            {
                move[2, 1].high = highChance;//D
                move[2, 0].low = midChanceLow; move[2, 0].high = midChanceHigh;//DL
                move[2, 2].low = midChanceLow1; move[2, 2].high = midChanceHigh1;//DR
                move[1, 0].low = lowChanceLow; move[1, 0].high = lowChanceHigh;//L
                move[1, 2].low = lowChanceLow1; move[1, 2].low = lowChanceHigh1;//R
            }
            else if (C > 0)//down left
            {
                move[2, 0].high = highChance;//DL
                move[2, 1].low = midChanceLow; move[2, 1].high = midChanceHigh;//D
                move[1, 0].low = midChanceLow1; move[1, 0].high = midChanceHigh1;//L
                move[0, 0].low = lowChanceLow; move[0, 0].high = lowChanceHigh;//UL
                move[2, 2].low = lowChanceLow1; move[2, 2].high = lowChanceHigh1;//DR
            }
            else//down right
            {
                move[2, 2].high = highChance;//DR
                move[2, 1].low = midChanceLow; move[2, 1].high = midChanceHigh;//D
                move[1, 2].low = midChanceLow1; move[1, 2].high = midChanceHigh1;//R
                move[2, 0].low = lowChanceLow; move[2, 0].high = lowChanceHigh;//DL
                move[0, 2].low = lowChanceLow1; move[0, 2].high = lowChanceHigh1;//UR
            }
        }
        else if (R > 0)//Above
        {
            if (C == 0)//same col 
            {
                move[0, 1].high = highChance;//U
                move[0, 0].low = midChanceLow; move[0, 0].high = midChanceHigh;//UL
                move[0, 2].low = midChanceLow1; move[0, 2].high = midChanceHigh1;//UR
                move[1, 0].low = lowChanceLow; move[1, 0].high = lowChanceHigh;//L
                move[1, 2].low = lowChanceLow1; move[1, 2].high = lowChanceHigh1;//R
            }
            else if (C > 0)//up left
            {
                move[0, 0].high = highChance;//UL
                move[0, 1].low = midChanceLow; move[0, 1].high = midChanceHigh;//U
                move[1, 0].low = midChanceLow1; move[1, 0].high = midChanceHigh1;//L
                move[2, 0].low = lowChanceLow; move[2, 0].high = lowChanceHigh;//DL
                move[0, 2].low = lowChanceLow1; move[0, 2].high = lowChanceHigh1;//UR
            }
            else//up right
            {
                move[0, 2].high = highChance;//UR
                move[0, 1].low = midChanceLow; move[0, 1].high = midChanceHigh;//U
                move[1, 2].low = midChanceLow1; move[1, 2].high = midChanceHigh1;//R
                move[0, 0].low = lowChanceLow; move[0, 0].high = lowChanceHigh;//UL
                move[2, 2].low = lowChanceLow1; move[2, 2].high = lowChanceHigh1;//DR
            }
        }
        else//R == 0
        {
            if (C > 0)//Left
            {
                move[1, 0].high = highChance;//L
                move[0, 0].low = midChanceLow; move[0, 0].high = midChanceHigh;//UL
                move[2, 0].low = midChanceLow1; move[2, 0].high = midChanceHigh1;//DL
                move[0, 1].low = lowChanceLow; move[0, 1].high = lowChanceHigh;//U
                move[2, 1].low = lowChanceLow1; move[2, 1].high = lowChanceHigh1;//D
            }
            else//Right
            {
                move[1, 2].high = highChance;//R
                move[0, 2].low = midChanceLow; move[0, 2].high = midChanceHigh;//UR
                move[2, 2].low = midChanceLow1; move[2, 2].high = midChanceHigh1;//DR
                move[0, 1].low = lowChanceLow; move[0, 1].high = lowChanceHigh;//U
                move[2, 1].low = lowChanceLow1; move[2, 1].high = lowChanceHigh1;//D
            }
        }
        return move;
    }

    private Box[,] UpdateMoveBox(Box[,] move, int[] start)
    {
        if (start[0] == 0 || start[0] == (height - 1))//no horizontal 
        {
            move[1, 0].low = 0; move[1, 0].high = 0;//L
            move[1, 2].low = 0; move[1, 2].high = 0;//R
            if (start[0] == 0)
            {
                move[0, 0].low = 0; move[0, 0].high = 0;//UL
                move[0, 2].low = 0; move[0, 2].high = 0;//UR
            }
            else
            {
                move[2, 0].low = 0; move[2, 0].high = 0;//DL
                move[2, 2].low = 0; move[2, 2].high = 0;//DR
            }

        }
        if (start[1] == 0 || start[1] == (width - 1))//no vertical
        {
            move[0, 1].low = 0; move[0, 1].high = 0;//U
            move[2, 1].low = 0; move[2, 1].high = 0;//D
            if (start[1] == 0)
            {
                move[0, 0].low = 0; move[0, 0].high = 0;//UL
                move[2, 0].low = 0; move[2, 0].high = 0;//DL
            }
            else
            {
                move[0, 2].low = 0; move[0, 2].high = 0;//UR
                move[2, 2].low = 0; move[2, 2].high = 0;//DR
            }
        }
        if (start[0] == 1)//near top then no up movement
        {
            move[0, 0].low = 0; move[0, 0].high = 0; //UL
            move[0, 1].low = 0; move[0, 1].high = 0; //U
            move[0, 2].low = 0; move[0, 2].high = 0; //UR
        }
        if (start[0] == height - 2)//near bottom then no down
        {
            move[2, 0].low = 0; move[2, 0].high = 0; //DL
            move[2, 1].low = 0; move[2, 1].high = 0; //D
            move[2, 2].low = 0; move[2, 2].high = 0; //DR
        }
        if (start[1] == 1)//near left then no left
        {
            move[0, 0].low = 0; move[0, 0].high = 0;//UL
            move[1, 0].low = 0; move[1, 0].high = 0;//L
            move[2, 0].low = 0; move[2, 0].high = 0;//DL
        }
        if (start[1] == width - 2)//near right then no right
        {
            move[0, 2].low = 0; move[0, 2].high = 0;//UR
            move[1, 2].low = 0; move[1, 2].high = 0;//R
            move[2, 2].low = 0; move[2, 2].high = 0;//DR
        }

        return move;
    }

    private bool IsDone(int[] start, int[] end)
    {
        if (Mathf.Abs(start[0] - end[0]) == 1 || Mathf.Abs(start[0] - end[0]) == 0)
        {
            if (Mathf.Abs(start[1] - end[1]) == 1)
                return true;
        }

        if (Mathf.Abs(start[1] - end[1]) == 1 || Mathf.Abs(start[1] - end[1]) == 0)
        {
            if (Mathf.Abs(start[0] - end[0]) == 1)
                return true;
        }
        return false;
    }

    private int[] MakeMove(int[] start, Box[,] move)
    {
        bool moveMade = false;
        while (!moveMade)
        {
            int moveNumber = Random.Range(1, 101);
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (move[i, j].low <= moveNumber && move[i, j].high >= moveNumber)
                    {
                            start[0] += i - 1;
                            start[1] += j - 1;
                            generatedMap[start[0], start[1]] = pathNumber;
                            moveMade = true;
                            break;
                    }
                }
            }
        }
        //Add side path
        for(int i = start[0] - 1; i < start[0] + 2; ++i)
        {
            for(int j = start[1] - 1; j < start[1] + 2; ++j)
            {
                generatedMap[i, j] = pathNumber;
            }
        }
        return start;
    }

    //Set blocks around the map, so that the player can't reach the edge of the map
    private void SetBoarder()
    {
        //Top
        for (int col = boarder; col < width - boarder; ++col)
        {
            if(generatedMap[boarder + 2, col] != 1 && generatedMap[boarder + 2, col] != 0)
                generatedMap[boarder + 2, col] = 8;
        }
        //Left
        for (int row = boarder; row < height - boarder; ++row)
        {
            if (generatedMap[row,boarder] != 1 && generatedMap[row, boarder] != 0)
                generatedMap[row,boarder] = 8;
        }
        //Bot
        for (int col = boarder; col < width- boarder; ++col)
        {
            if (generatedMap[height - boarder, col] != 1 && generatedMap[height - boarder, col] != 0)
                generatedMap[height - boarder, col] = 8;
        }
        //Right
        for(int row = boarder; row < height - boarder - 1; ++row)
        {
            if (generatedMap[row, width - boarder - 1] != 1 && generatedMap[row, width - boarder - 1] != 0)
                generatedMap[row, width - boarder - 1] = 8;
        }

    }

    //Store the map in a text file, so that the visited map will persist
    public void StoreMap(string filepath)
    {
        var streamWriter = new StreamWriter(@filepath);


        for (int i = 0; i < height; ++i)
        {
            for (int j = 0; j < width; ++j)
            {
                streamWriter.Write(generatedMap[i, j] + " ");
            }
            streamWriter.WriteLine();
        }

        streamWriter.Close();
    }

    //loads a given map based on the filepath
    public void LoadMap(string filepath)
    {
        //Load the map
        StreamReader sr = new StreamReader(@filepath);
        string[] s = new string[height];
        for (int i = 0; i < height; ++i)
        {
            s[i] = sr.ReadLine();
        }
        int[] iray = new int[width];
        for (int i = 0; i < height; ++i)
        {
            string[] t = s[i].Split(' ');
            for (int j = 0; j < t.Length - 1; ++j)
            {
                iray[j] = System.Convert.ToInt32(t[j]);
                generatedMap[i, j] = iray[j];
            }

        }
    }

    //returns the 2D array that is the generated or loaded map
    public int[,] GetMap()
    {
        return generatedMap;
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------------------
    // Use this for initialization
    void Awake()
    {
        //test code
        TileMapperOld map = new TileMapperOld();
        eMapStyle mapStyle = eMapStyle.Forest;
        Debug.Log("Generating Map...");
        map.GenerateMap(mapStyle, System.Convert.ToInt32("1111", 2));
        Debug.Log("Map Generated");
        Debug.Log("Storing Map...");
        map.StoreMap("C:\\Users\\cwlarson\\OneDrive\\Tile Mapper\\Assets\\Scripts\\Test.txt");
        Debug.Log("Map Stored");
        //test loading to storing
        map.LoadMap("C:\\Users\\cwlarson\\OneDrive\\Tile Mapper\\Assets\\Scripts\\Test.txt");
        map.StoreMap("C:\\Users\\cwlarson\\OneDrive\\Tile Mapper\\Assets\\Scripts\\TestDest.txt");
    }
}


