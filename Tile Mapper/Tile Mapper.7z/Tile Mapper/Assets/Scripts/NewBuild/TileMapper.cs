﻿using UnityEngine;
using System.IO;

[System.Serializable]
public class TileMapper {

    private MapTypes mapTypes;
    private int[,] map;
    public TileMapper(MapTypes mTypes, int[,] map)
    {
        mapTypes = mTypes;
        this.map = map;
    }

    public void MapTiles()
    {
        int height = map.GetLength(0);
        int width = map.Length / map.GetLength(0);

        for(int row = 0; row < height; ++row)
        {
            for(int col = 0; col < width; ++col)
            {
                int tileKey = map[row, col];
                TileSet tree = new TileSet("ForestTreeTileSet",(int)TileType.Tree, MapTypes.Forest, 3, 4, "Prefabs\\Forest\\", false);
            }
        }
    }
}
