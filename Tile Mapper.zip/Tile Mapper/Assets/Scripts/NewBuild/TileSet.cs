﻿using UnityEngine;
using System.IO;

[System.Serializable]
public class TileSet {

    public string TileName;
    public int TileKeyNumber;
    public MapTypes MapTypes;
    public int Width;
    public int Height;
    public string FilePath;
    private Transform ParentTileTransform;
    public Transform[,] TileSprites;
    public bool RandomTiles;


    public TileSet(string tileName, int tileKeyNumber, MapTypes mapType, int width, int height, string filePath, bool randomTiles)
    {
        this.TileName = tileName;
        this.TileKeyNumber = tileKeyNumber;
        this.MapTypes = mapType;
        this.Width = width;
        this.Height = height;
        this.FilePath = filePath;
        LoadParent(filePath, tileName);
        if(TileSprites == null)
            BuildTileSet();
        this.RandomTiles = randomTiles;
    }

    public void LoadParent(string filepath, string tilename)
    {
        ParentTileTransform = Resources.Load(filepath + tilename, typeof(Transform)) as Transform;
        if (ParentTileTransform == null)
            Debug.Log("ParentTileTransform is still null");
    }

    public void BuildTileSet()
    {
        TileSprites = new Transform[Height, Width];
        for (int row = 0; row < Height; ++row)
        {
            for(int col = 0; col < Width; ++col)
            {
                int index = (row * Width) + col;
                var childTransform = ParentTileTransform.GetChild(index);
                if(childTransform != null)
                {
                    TileSprites[row, col] = childTransform;
                }
                else
                {
                    //could do a default tile (pink?)
                }
            }
        }
    }


    //Find a work around for trees
    public void Draw(Vector2 topLeft)
    {
        if(TileSprites == null)
        {
            BuildTileSet();
        }

        if (RandomTiles)
        {
            int i = Random.Range(0, Height);
            int j = Random.Range(0, Width);
            SpriteRenderer.Instantiate(TileSprites[i, j], topLeft, Quaternion.identity);
        }
        else if(TileKeyNumber == 4 || TileKeyNumber == 64)
        {
            for (int row = 0; row < Height; ++row)
            {
                for (int col = 0; col < Width; ++col)
                {
                    Vector2 pos = new Vector2(topLeft.x + (col - 1), topLeft.y - (row - 3));
                    SpriteRenderer.Instantiate(TileSprites[row, col], pos, Quaternion.identity);
                }
            }
        }
        else
        {
            for (int row = 0; row < Height; ++row)
            {
                for (int col = 0; col < Width; ++col)
                {
                    Vector2 pos = new Vector2(topLeft.x + col, topLeft.y - row);
                    SpriteRenderer.Instantiate(TileSprites[row, col], pos, Quaternion.identity);
                }
            }
        }
    }
}
