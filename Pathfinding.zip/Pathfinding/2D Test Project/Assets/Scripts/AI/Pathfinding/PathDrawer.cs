﻿using System;
using System.Collections.Generic;
using UnityEngine;
public class PathDrawer : MonoBehaviour
{
    public Vector2 PathStart = new Vector2();
    public Vector2 PathEnd = new Vector2();

    public Pathfinder pathfinder;
    public MapGenerator MapGen;

    public List<Color> availableColors;

    public float TimeToDraw = 10.0f;

    private bool isMapSet = false;
    private bool firstClick = true;


    void OnEnable()
    {
        availableColors = new List<Color> { Color.white, Color.yellow, Color.red, Color.magenta, Color.green };
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            var mousePos = Input.mousePosition;
            var pos = Camera.main.ScreenToWorldPoint(mousePos);
            int roundedX = (int)Math.Round(pos.x);
            int roundedY = (int)Math.Round(pos.y);

            var intPos = new Vector2(roundedX, -roundedY);

            int[,] mapcopy = MapGen.GetCopyOfMap();
            if (isMapSet == false)
            {
                pathfinder.SetMap(mapcopy);
                isMapSet = true;
            }

            if(firstClick == true)
            {
                firstClick = false;
                PathStart = intPos;
                Debug.Log("Setting start of path to: " + intPos);
            }
            else
            {
                firstClick = true;
                PathEnd = intPos;
                Debug.Log("Setting end of path to: " + intPos);
                var colorOfPath = availableColors[UnityEngine.Random.Range(0, availableColors.Count)];
                //Debug.DrawLine(new Vector2(PathStart.x,-PathStart.y),
                //               new Vector2(PathEnd.x,-PathEnd.y),
                //               colorOfPath, TimeToDraw, false);
                if (pathfinder.FindShortestPath(PathStart, PathEnd) == true)
                {
                    var path = pathfinder.FinalPath;

                    for (LinkedListNode<Vector2> node = path.First; node != path.Last;)
                    {
                        var drawFrom = node.Value;
                        node = node.Next;
                        var drawTo = node.Value;
                        Debug.DrawLine(drawFrom, drawTo, colorOfPath, TimeToDraw, false);
                    }
                }
                else
                {
                    Debug.LogWarning("PATH NOT FOUND-> From " + PathStart + " to " + PathEnd);
                }
                
                PathEnd = new Vector2();
                PathStart = new Vector2();
            }

        }
    }
}
