﻿using System.Collections.Generic;
using UnityEngine;
using System.IO;
using LitJson;

public class TileManager {

    public Dictionary<int, TileSet> tileDictionary;

    //Find a way to populate the Dictionary given JSON files
    //Why do json files not show up in visual studio?
    //Test the populated Dictionary with a test map
    //Get the map working again
    //After that, get the load and save stuff worked out
    //Start working on town sets and additional scene props
    //Start thinking about how the eneimes/animals will be placed in the map

    public TileManager()
    {
        tileDictionary = new Dictionary<int, TileSet>();
        JsonData tileSets = JsonMapper.ToObject(File.ReadAllText(Application.dataPath + "\\Scripts\\NewBuild\\JsonFiles\\Forest.json"));

        for (int i = 0; i < tileSets.Count; ++i)
        {
            tileDictionary.Add((int)tileSets[i]["TileKeyNumber"], new TileSet(tileSets[i]["TileName"].ToString(), (int)tileSets[i]["TileKeyNumber"],
                (MapTypes)System.Enum.Parse(typeof(MapTypes), tileSets[i]["MapTypes"].ToString()), (int)tileSets[i]["Width"], (int)tileSets[i]["Height"], 
                tileSets[i]["FilePath"].ToString(), (bool)tileSets[i]["RandomTiles"]));
        }

    }
}
