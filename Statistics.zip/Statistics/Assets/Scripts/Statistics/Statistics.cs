﻿using UnityEngine;
public class Statistics : MonoBehaviour
{
    public int HitPoints;
    public int ResourcePool;
    public int Defense;
    public int MeleeAttack;
    public int RangedAttack;

    public float AttackSpeed;
    public float MoveSpeed;

    public static StatisticsEvent UpdateStatsEvent = new StatisticsEvent();
    void OnEnable()
    {
        UpdateStatsEvent.AddListener(UpdateStats);
    }

    void OnDisable()
    {
        UpdateStatsEvent.RemoveListener(UpdateStats);
    }

    /// <summary>
    ///Called when triggered by StatsUpdateTrigger.
    ///Updates the passed Statistics object with all other objects that are subscribing to the UpdateStatsEvent
    ///This will clear the stats of the passed in object, and ADD the stats of all other objects to the passed in object.
    /// </summary>
    /// <param name="statsToUpdate"></param>
    private void UpdateStats(Statistics statsToUpdate)
    {
        //if the passed object reference is not pointing to this same instance, add the stats of the passed stats to this stat value.
        if (!Object.ReferenceEquals(statsToUpdate,this))
        {
            statsToUpdate.AddStats(this);
        }
    }

    public void AddStats(Statistics otherStats)
    {
        HitPoints += otherStats.HitPoints;
        ResourcePool += otherStats.ResourcePool;
        Defense += otherStats.Defense;
        MeleeAttack += otherStats.MeleeAttack;
        RangedAttack += otherStats.RangedAttack;
        AttackSpeed += otherStats.AttackSpeed;
        MoveSpeed += otherStats.MoveSpeed;
    }

    public void SetDefaultValues()
    {
        HitPoints = 0;
        ResourcePool = 0;
        Defense = 0;
        MeleeAttack = 0;
        RangedAttack = 0;
        AttackSpeed = 1.0f;
        MoveSpeed = 1.0f;
    }

    public override string ToString()
    {
        string str = "";
        str += "HitPoints: " + HitPoints + "\n";
        str += "ResourcePool: " + ResourcePool +"\n";
        str += "Defense: " + Defense + "\n";
        str += "MeleeAttack: " + MeleeAttack + "\n";
        str += "RangedAttack: " + RangedAttack + "\n";
        str += "AttackSpeed: " + AttackSpeed + "\n";
        str += "MoveSpeed: " + MoveSpeed + "\n";
        return str;
    }
}
