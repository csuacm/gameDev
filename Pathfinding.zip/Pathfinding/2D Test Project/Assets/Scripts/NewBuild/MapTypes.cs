﻿[System.FlagsAttribute]
public enum MapTypes {
    None = 0,
    Forest = 1,
    Desert = 1 << 1,
    Tundra = 1 << 2,
    Cave = 1 << 3
}
