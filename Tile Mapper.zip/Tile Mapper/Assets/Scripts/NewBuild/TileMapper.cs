﻿using UnityEngine;
using System.IO;

[System.Serializable]
public class TileMapper {

    private MapTypes mapTypes;
    private int[,] map;
    public TileMapper(MapTypes mTypes, int[,] map)
    {
        mapTypes = mTypes;
        this.map = map;
    }

    public void MapTiles()
    {
        TileManager tileManager = new TileManager();

        int height = map.GetLength(0);
        int width = map.Length / map.GetLength(0);

        for(int row = 0; row < height; ++row)
        {
            for(int col = 0; col < width; ++col)
            {
                int tileKey = map[row, col];
                tileManager.tileDictionary[tileKey].Draw(new Vector2(col, -row));
            }
        }
    }
}
