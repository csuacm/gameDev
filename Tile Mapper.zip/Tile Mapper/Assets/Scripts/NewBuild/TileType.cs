﻿public enum TileType
{
    Unreachable = 0,
    
    //Path Types
    Path = 1 << 0,
    PathUpLeftInner = 3,
    PathUpLeftOuter = 25,
    PathUp = 15,
    PathUpRightInner = 9,
    PathUpRightOuter = 45,
    PathLeft = 83,
    PathRight = 297,
    PathDownLeftInner = 65,
    PathDownLeftOuter = 209,
    PathDown = 449,
    PathDownRightInner = 257,
    PathDownRightOuter = 417,


    DefaultTile = 1 << 1,//2
    Tree = 1 << 2,
    Rock = 1 << 3,
    Bush = 1 << 4,
    Log = 1 << 5,//32
    Boarder = 1 << 6,
    Barrel = 1 << 7,//128
    Chest = 1 << 8
}
